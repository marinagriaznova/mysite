'''from django.contrib import admin
from .models import AnimeModel

# admin.site.register(AuthorModel)

admin.site.register(AnimeModel)'''