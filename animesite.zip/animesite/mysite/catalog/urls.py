'''from django.urls import path
from . import views

urlpatterns = [
    path('add-anime', views.new_anime, name="add-anime"),
    path('registration', views.registration, name="#registration"),
    path('about-us', views.about_us, name="#about-us"),
    path('contacts', views.contacts, name="#contacts"),
    path('home-page', views.home_page, name="#home-page"),
    path('new-titles', views.new_titles, name="#new-titles"),
    ]'''