'''from django import forms

from .models import AnimeModel 
#StudioModel, GenreModel

class NewAnimeForm(forms.ModelForm):
	class Meta:
		model = AnimeModel
		fields = ('__all__')'''